package se.test.common;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {
	
	public static WebDriver driver;	
	
	Properties prop = new Properties();
	InputStream inStr = null;
	String launchDriver = null;
	String launchUrl = null;
	String driverPath = null;
	
		
	@BeforeMethod
	@Parameters(value={"browser"})
	public void setUp(String browser) throws Exception {	
	
		inStr = new FileInputStream("configProperties.xml");
		prop.load(inStr);
		launchDriver = prop.getProperty("driver");
		driverPath = prop.getProperty("driverPath");
		launchUrl = prop.getProperty("url");
		
		if (browser.equalsIgnoreCase("chrome")) {
			DesiredCapabilities capability = DesiredCapabilities.chrome();
            capability.setBrowserName("chrome");
            capability.setPlatform(Platform.WINDOWS);
            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
            driver.get(launchUrl);	
			driver.manage().window().maximize();		
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
		} else if (browser.equalsIgnoreCase("IE")) {
			
   			DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
            capability.setBrowserName("internet explorer");
            capability.setPlatform(Platform.WINDOWS);
            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
            driver.get(launchUrl);	
			driver.manage().window().maximize();		
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		} else if (browser.equalsIgnoreCase("firefox")) {
			
			DesiredCapabilities capability = DesiredCapabilities.firefox();
            capability.setBrowserName("firefox");
            capability.setPlatform(Platform.WINDOWS);
            driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capability);
            driver.get(launchUrl);	
			driver.manage().window().maximize();		
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		} else if (browser.equalsIgnoreCase("default")) {
		
			System.setProperty(launchDriver, driverPath);
			launchUrl = prop.getProperty("url");
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Parthi\\chromeDriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-infobars");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();		
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			launchUrl = prop.getProperty("url");
			driver.get(launchUrl);					
		}
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();		
	}
}