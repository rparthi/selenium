package se.test.cucumber;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import se.test.common.BaseClass;

public class CucumberHooks extends BaseClass {
	
	@Before
    public void beforeScenario() throws Exception
	{
		setUp("default");
	}	
	
	@After
	public void afterScenario() 
	{
		tearDown();
	}

}