package se.test.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

//import cucumber.api.junit.Cucumber;
//import org.junit.runner.RunWith;

//@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/se/test/features",
		glue={"se/test/scripts/cucumber/stepdefinitions","se/test/cucumber"},
		monochrome = true,
		tags ={"@ValidLogin"},
		        plugin = {
		                "pretty",
		                "html:src/test/java/se/test/reports/cucumber-html-report",
		                "json:src/test/java/se/test/reports/CucumberTestReport.json",
		                "rerun:target/cucumber-reports/rerun.txt"
		        }
		)

public class TestRunner extends AbstractTestNGCucumberTests{
		
}