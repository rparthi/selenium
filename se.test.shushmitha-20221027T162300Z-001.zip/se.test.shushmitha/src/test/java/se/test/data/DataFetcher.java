package se.test.data;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class DataFetcher {
	Properties prop = new Properties();
	InputStream inStr = null;
	String user_name = null;
	String booking_data = null;
	String config_file_path = "configProperties.xml";
	
	public String getUserName(String userType) throws Exception {
		inStr = new FileInputStream(config_file_path);
		prop.load(inStr);

		if(userType != null) {
			if(userType.equals("EMP")) {
				user_name = prop.getProperty("empUserName");
			} else if (userType.equals("HOD")) {
				user_name = prop.getProperty("hodUserName");				
			} else if (userType.equals("HR")) {
				user_name = prop.getProperty("hrUserName");				
			} else if (userType.equals("OPERATOR")) {
				user_name = prop.getProperty("operatorUserName");				
			} else if (userType.equals("ADMIN")) {
				user_name = prop.getProperty("adminUserName");				
			}			
		}
		return user_name;		
	}

	public String getPassWord(String userType) throws Exception {
		inStr = new FileInputStream(config_file_path);
		prop.load(inStr);

		if(userType != null) {
			if(userType.equals("EMP")) {
				user_name = prop.getProperty("empPass");
			} else if (userType.equals("HOD")) {
				user_name = prop.getProperty("hodPass");				
			} else if (userType.equals("HR")) {
				user_name = prop.getProperty("hrPass");				
			} else if (userType.equals("OPERATOR")) {
				user_name = prop.getProperty("operatorPass");				
			} else if (userType.equals("ADMIN")) {
				user_name = prop.getProperty("adminPass");				
			}			
		}
		return user_name;		
	}
	
	public String getBookingDetails(String bookingData) throws Exception {
		inStr = new FileInputStream(config_file_path);
		prop.load(inStr);

		if(bookingData != null) {
			if(bookingData.equals("startPoint")) {
				booking_data = prop.getProperty("startPoint");
			} else if (bookingData.equals("dropPoint")) {
				booking_data = prop.getProperty("dropPoint");				
			} else if (bookingData.equals("purpose")) {
				booking_data = prop.getProperty("purpose");				
			} 			
		}
		return booking_data;		
	}
}