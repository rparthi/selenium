package se.test.helpers;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class SeleniumWrapper {

	public SeleniumWrapper(WebDriver driver) {
		super();
		this.driver = driver;
	}

	WebDriver driver;
	
	// Enum for the Locator Types
	public enum locatorType {
		ID, NAME, CSS, LINKTEXT, PARTIAL_LINKTEXT, TAG_NAME, CLASS_NAME, XPATH
	}
	
	public WebElement locateElement(locatorType locType, String elementValue) {
		try {
			switch(locType) {
			case ID:
					return driver.findElement(By.id(elementValue));
			case NAME:
					return driver.findElement(By.name(elementValue));
			case CSS:
					return driver.findElement(By.cssSelector(elementValue));
			case LINKTEXT:
					return driver.findElement(By.linkText(elementValue));
			case PARTIAL_LINKTEXT:
					return driver.findElement(By.partialLinkText(elementValue));
			case TAG_NAME:
					return driver.findElement(By.tagName(elementValue));
			case CLASS_NAME:
					return driver.findElement(By.className(elementValue));
			case XPATH:
					return driver.findElement(By.xpath(elementValue));
			default:
				break;
			}			
		} catch(NoSuchElementException e) {
			System.out.println(("Unable to locate the element \'" + elementValue 
											+ "\' using locator \'" + locType + "\'"));
			throw e;
		}
		return null;
	}			
		
	/*
	 *  WebDriver Functions
	 */
	// Function to verify the title of the page
	public void verifyTitle(String expectedTitle) {
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);			
	}
	
	/*
	 *  WebElement GET Functions
	 */	
	// Function to get the inner text of an element
	public String  getVisibleInnerText(locatorType locType, String elementValue) {
		String innerText = locateElement(locType, elementValue).getText();		
		return innerText;		
	}

	/*
	 *  WebElement Is and Verify Functions
	 */
	
	// Function to find if an Element is displayed
	// Returns true or false; Does not throw error if not displayed
	public boolean isDisplayed(locatorType locType, String elementValue) {
		WebElement elem = locateElement(locType, elementValue);
		boolean bool = elem.isDisplayed();
		return bool;
	}
	
	/*
	 *  WebElement ACTION Functions
	 */	
	// Function to click an element
	public void clickElement(locatorType locType, String elementValue) {
		WebElement elem = locateElement(locType, elementValue);
		boolean bool = elem.isDisplayed();
		if (bool) {
			elem.click();			
		}else {
			throw new ElementNotVisibleException(elementValue);
		}
	}	
	
	// Function to clear a text entry
	public void clearText(locatorType locType, String elementValue) {
		WebElement elem = locateElement(locType, elementValue);
		boolean bool = elem.isDisplayed();
		if (bool) {
			elem.clear();			
		}else {
			throw new ElementNotVisibleException(elementValue);
		}		
	}
	
}