package se.test.helpers;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Utilities {

	// Enum for the sleep time
	public enum SleepTime {
		ONE_SEC, TWO_SEC, THREE_SEC, FOUR_SEC, FIVE_SEC
	}
	
	public int randomNum(int min, int max) {
		Random rand = new Random();
		int randValue =  rand.nextInt(max-min +1 )+min;
		return randValue;		
	}	
	
	public void sleep(SleepTime sleep_time) throws Exception {
		
		if ((sleep_time != null)) {
			if (sleep_time.toString() 			== "ONE_SEC"){
				TimeUnit.SECONDS.sleep(1);
			} else if (sleep_time.toString() 	== "TWO_SEC"){
				TimeUnit.SECONDS.sleep(2);
			} else if (sleep_time.toString()	== "THREE_SEC"){
				TimeUnit.SECONDS.sleep(3);
			} else if (sleep_time.toString() 	== "FOUR_SEC"){
				TimeUnit.SECONDS.sleep(4);
			} else if (sleep_time.toString() 	== "FIVE_SEC"){
				TimeUnit.SECONDS.sleep(5);	
			}
		}
	}
}