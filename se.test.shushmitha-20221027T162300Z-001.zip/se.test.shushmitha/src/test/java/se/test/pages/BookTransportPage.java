package se.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import se.test.data.DataFetcher;

public class BookTransportPage {
	public BookTransportPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebDriver driver;
	DataFetcher df = new DataFetcher();
	
	// Define page
	By journeyDate 		=  By.id("datetimepicker1");
	By journeyTime 		=  By.id("datetimepicker3");
	By startPoint 		=  By.id("startingPoint");
	By dropPoint 		=  By.id("dropPoint");
	By placeToBeVisited =  By.id("placeToBeVisited");
	By noOfPassengers 	=  By.id("passengers");
	By viewPassenger 	=  By.id("view-passenger-details");
	By purpose 			=  By.id("purpose");
	By specialRequest 	=  By.id("specialRequest");
	By createRequest	=  By.id("createrequest");
	By bookingID		=  By.xpath("//strong[@id='bookingId']");
	By okButton			=  By.id("btn");
	
	public void selectJourneyDate() {
		driver.findElement(journeyDate).click();
	}	
	
	public void selectJourneyTime() {
		driver.findElement(journeyTime).click();
	}	
	
	public void fillStartpoint(String inpStartPoint) throws Exception {
		String start_point = df.getBookingDetails(inpStartPoint);
		driver.findElement(startPoint).sendKeys(start_point);
	}
	
	public void fillDropPoint(String inpDropPoint) throws Exception {
		String drop_point = df.getBookingDetails(inpDropPoint);
		driver.findElement(dropPoint).sendKeys(drop_point);
	}
	
	public void fillPlaceToBeVisited(String inpVisit) {
		driver.findElement(placeToBeVisited).sendKeys(inpVisit);
	}
	
	public void fillPurpose(String Purporse) throws Exception {
		String purpose_value = df.getBookingDetails(Purporse);
		driver.findElement(purpose).sendKeys(purpose_value);
	}
	
	public void fillSpecialRequest(String spl) {
		driver.findElement(specialRequest).sendKeys(spl);
	}
	
	public void submitCreateRequest() {
		driver.findElement(createRequest).click();
	}
	
	public String getBookingId() {
		String bookId = driver.findElement(bookingID).getText();
		return bookId;
	}
	
	public void clickOkButton() {
		driver.findElement(okButton).click();
	}
}