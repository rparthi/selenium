package se.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import se.test.common.BaseClass;

public class HeaderPanel extends BaseClass {
	public HeaderPanel(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	WebDriver driver;
	String etms_title = "Employee Transport Management System";
	
	// Define panel
	By logout 	= By.xpath("//a[@class='check_logout']");
	By etmsTitle= By.className("subtitle");
	
	// Functions for Panel
	public boolean isEtmsTitlePresent() {
		boolean etmsTitleBool = driver.findElement(etmsTitle).getText().matches(etms_title);
		return etmsTitleBool;
	}
	
	public String getEtmsPageTitle() {
		String title = driver.getTitle();
		return title;
	}
	
	public boolean isLogoutDisplayed() {		
		boolean logoutDisplaybool = driver.findElement(logout).isDisplayed();
		return logoutDisplaybool;
	}
	
	public void clickLogout() {
		WebElement element=driver.findElement(logout);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", element);
	}	
}