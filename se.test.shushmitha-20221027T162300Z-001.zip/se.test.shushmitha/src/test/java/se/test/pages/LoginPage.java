package se.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import se.test.data.DataFetcher;

public class LoginPage { 
	
	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	WebDriver driver;
	DataFetcher df = new DataFetcher();
	 
	// Define page 
	By signInText 	= By.className("panel-heading");
	By userName 	= By.id("username");
	By password 	= By.id("password");
	By loginButton 	= By.tagName("button");
	By logo 		= By.tagName("img");
	
	String errorTxt = "Username or Password is incorrect";
		
	// Functions for the Page
	public void setValidUserName(String userType) throws Exception {
		String user_name = df.getUserName(userType);
		driver.findElement(userName).sendKeys(user_name);
	}
	
	public void setInValidUserName() throws Exception {
		driver.findElement(userName).sendKeys("user_invalid");
	}

	public void setPassWord(String userType) throws Exception {
		String user_pass = df.getPassWord(userType);
		driver.findElement(password).sendKeys(user_pass);
	}

	public void setInvalidPassWord() throws Exception {
		driver.findElement(password).sendKeys("pass_invalid");
	}

	public void clickLoginButton() {
		driver.findElement(loginButton).click();
	}

	public boolean isSignInTextDisplayed() {
		boolean displayBool = driver.findElement(signInText).isDisplayed();
		return displayBool;
	}

	public boolean isLogoDisplayed() {
		boolean logoBool = driver.findElement(logo).isDisplayed();
		return logoBool;
	}		
}