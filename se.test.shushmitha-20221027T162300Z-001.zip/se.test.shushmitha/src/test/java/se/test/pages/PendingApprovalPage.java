package se.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PendingApprovalPage {

	public PendingApprovalPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	WebDriver driver;

    // Define elements
    By plusIcon         =  By.xpath("//*[contains(@class,'glyphicon glyphicon-plus-sign')]");
    By rejectButton     =  By.name("submit");
    By approveButton    =  By.xpath("//*[text()='Approve']");
    By okButton         =  By.id("approvedHOD");
    By pendingAppMenu	=  By.id("pendingapproval");
    
    public void clickPlusIcon() throws Exception {
        driver.findElement(plusIcon).click();
    }
    
    public void clickApprovetButton() throws Exception {
        driver.findElement(approveButton).click();
    }

    public void clickOkButton() throws Exception {
        driver.findElement(okButton).click();
    }        

    public void clickRejectButton() throws Exception {
        driver.findElement(rejectButton).click();
    }    
    
    public boolean isPendingAppMenuDisplayed() {
    	boolean value = driver.findElement(pendingAppMenu).isDisplayed();
    	return value;
    }
    
    public boolean isApproveButtonDisplayed() {
    	boolean value = driver.findElement(approveButton).isDisplayed();
    	return value;
    }
}
