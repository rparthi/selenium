package se.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PendingAssignmentPage {

	public PendingAssignmentPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	WebDriver driver;

    // Define elements
    By plusIcon            =  By.xpath("//*[contains(@class,'glyphicon glyphicon-plus-sign')]");
    By assignButton        =  By.xpath("//button[text()='Assign']");
    By rejectButton        =  By.xpath("//button[text()='Reject']");
    By okButton            =  By.xpath(".//*[@id='approvedHR']");
    By cabOper             =  By.xpath("//td[@class='even']/select");    
    By pendingAssignMenu   =  By.id("pendingapproval");
    
    public void clickPlusIcon() throws Exception {
        driver.findElement(plusIcon).click();
    }

    public void selectCabOperator() throws Exception {
    	
    	Select select = new Select(driver.findElement(cabOper));
    	select.selectByIndex(2);
    }
    
    public void clickAssignButton() throws Exception {
        driver.findElement(assignButton).click();
    }
    
    public void clickOkButton() throws Exception {
        driver.findElement(okButton).click();
    }
    
    public boolean isPendingAssignMenuDisplayed() {
    	boolean value = driver.findElement(pendingAssignMenu).isDisplayed();
    	return value;
    }
    
    public boolean isAssignButtonDisplayed() {
    	boolean value = driver.findElement(assignButton).isDisplayed();
    	return value;
    }
}
