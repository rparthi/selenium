$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Scenario1.feature");
formatter.feature({
  "line": 1,
  "name": "Login_Logout feature",
  "description": "",
  "id": "login-logout-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 8107596739,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Employee login with valid username and password",
  "description": "",
  "id": "login-logout-feature;employee-login-with-valid-username-and-password",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 12,
      "name": "@ValidLogin"
    },
    {
      "line": 12,
      "name": "@emp"
    }
  ]
});
formatter.step({
  "line": 14,
  "name": "I am on etms login page with title \"Employee Transport Management System\"",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "I should see \"Sign In\" Label",
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "I should enter \"EMP\" in Username or Email input field",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "I should enter \"EMP\" in Password input field",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "I click on Login button",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "I should be navigated to \"Book Transport\" Page",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "I click on Logout option in Book Transport Page",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "I should be navigated to \"Sign In\" Page",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Employee Transport Management System",
      "offset": 36
    }
  ],
  "location": "LoginLogout_SD.launchLoginPage(String)"
});
formatter.result({
  "duration": 1164299854,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Sign In",
      "offset": 14
    }
  ],
  "location": "LoginLogout_SD.seeLabel(String)"
});
formatter.result({
  "duration": 26315363,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "EMP",
      "offset": 16
    }
  ],
  "location": "LoginLogout_SD.enterUserName(String)"
});
formatter.result({
  "duration": 1061189654,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "EMP",
      "offset": 16
    }
  ],
  "location": "LoginLogout_SD.enterPassword(String)"
});
formatter.result({
  "duration": 1060528321,
  "status": "passed"
});
formatter.match({
  "location": "LoginLogout_SD.clickLoginButton()"
});
formatter.result({
  "duration": 2050372807,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Book Transport",
      "offset": 26
    }
  ],
  "location": "LoginLogout_SD.navigateToPage(String)"
});
formatter.result({
  "duration": 1015055921,
  "status": "passed"
});
formatter.match({
  "location": "LoginLogout_SD.clickLogout()"
});
formatter.result({
  "duration": 3482592153,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Sign In",
      "offset": 26
    }
  ],
  "location": "LoginLogout_SD.navigateToPage(String)"
});
formatter.result({
  "duration": 2028929121,
  "status": "passed"
});
formatter.after({
  "duration": 620912856,
  "status": "passed"
});
});