package se.test.scripts.cucumber.stepdefinitions;

import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.BookTransportPage;

import org.testng.Assert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookTransport_SD extends BaseClass {
	
	BookTransportPage bookTransport = new BookTransportPage(driver);
	Utilities util = new Utilities();
	
	@Then("^I should select date from journey Date field$")
	public void selectDefaultDate() throws Throwable {
		bookTransport.selectJourneyDate();
		util.sleep(SleepTime.ONE_SEC);		
	}

	@Then("^I should select time from journey Time field$")
	public void selectDefaultTime() throws Throwable {
		bookTransport.selectJourneyTime();
		util.sleep(SleepTime.ONE_SEC);		
	}

	@Then("^I should enter value as \"([^\"]*)\" in Starting Point input field$")
	public void fillStartPoint(String srtPoint) throws Throwable {
		bookTransport.fillStartpoint(srtPoint);	
		util.sleep(SleepTime.ONE_SEC);
	}

	@Then("^I should enter value in \"([^\"]*)\" Drop Point input field$")
	public void fillDropPoint(String dropPoint) throws Throwable {
		bookTransport.fillDropPoint(dropPoint);
		util.sleep(SleepTime.ONE_SEC);
	}

	@Then("^I should enter value in \"([^\"]*)\" Purpose input field$")
	public void fillPurpose(String purpose) throws Throwable {
		bookTransport.fillPurpose(purpose);
		util.sleep(SleepTime.ONE_SEC);
	}

	@When("^I click on Create Request button$")
	public void clickCreateRequestButton() throws Throwable {
		bookTransport.submitCreateRequest();
		util.sleep(SleepTime.TWO_SEC);
	}

	@Then("^I should see booking Id with message \"([^\"]*)\" in Popup$")
	public void findBookingConfirmationID(String message) throws Throwable {
		Assert.assertEquals(message, "Your booking is accepted!");
		util.sleep(SleepTime.ONE_SEC);
	}

	@Then("^I click on OK button$")
	public void clickOkButton() throws Throwable {
		bookTransport.clickOkButton();
		util.sleep(SleepTime.TWO_SEC);
	}	
}
