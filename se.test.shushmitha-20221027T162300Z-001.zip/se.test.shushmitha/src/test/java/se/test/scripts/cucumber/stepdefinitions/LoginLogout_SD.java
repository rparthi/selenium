package se.test.scripts.cucumber.stepdefinitions;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.HeaderPanel;
import se.test.pages.LoginPage;
import se.test.pages.PendingApprovalPage;
import se.test.pages.PendingAssignmentPage;

public class LoginLogout_SD extends BaseClass {
	
	HeaderPanel headerPanel = new HeaderPanel(driver);
	LoginPage loginPage = new LoginPage(driver);
	PendingApprovalPage pendingApprovalPage = new PendingApprovalPage(driver);
	PendingAssignmentPage pendingAssignPage = new PendingAssignmentPage(driver);
	Utilities util = new Utilities();
	
	@Given("^I am on etms login page with title \"([^\"]*)\"$")
	public void launchLoginPage(String title) throws Throwable {
		String etmsTitle = headerPanel.getEtmsPageTitle();
		Assert.assertEquals(title, etmsTitle);
		util.sleep(SleepTime.ONE_SEC);
	}
	
	@Then("^I should see \"([^\"]*)\" Label$")
	public void seeLabel(String label) throws Throwable {
		boolean bool = loginPage.isSignInTextDisplayed();
		Assert.assertEquals(true, bool);
	}	
	
	@Then("^I should enter \"([^\"]*)\" in Username or Email input field$")
	public void enterUserName(String user_type) throws Throwable {
		if (user_type.equals("InvalidUserName")) {
			loginPage.setInValidUserName();
			util.sleep(SleepTime.ONE_SEC);
		} else {
			loginPage.setValidUserName(user_type);
			util.sleep(SleepTime.ONE_SEC);
		}
	}

	@Then("^I should enter \"([^\"]*)\" in Password input field$")
	public void enterPassword(String pass) throws Throwable {
		if (pass.equals("InvalidPassword")) {
			loginPage.setInvalidPassWord();
			util.sleep(SleepTime.ONE_SEC);
		} else {
			loginPage.setPassWord(pass);			
			util.sleep(SleepTime.ONE_SEC);
		}
	}

	@When("^I click on Login button$")
	public void clickLoginButton() throws Throwable {
		loginPage.clickLoginButton();
		util.sleep(SleepTime.TWO_SEC);
	}

	@Then("^I should be navigated to \"([^\"]*)\" Page$")
	public void navigateToPage(String page) throws Throwable {
		if (page.equals("Book Transport")) {
			Assert.assertEquals(true, headerPanel.isLogoutDisplayed());
			util.sleep(SleepTime.ONE_SEC);
		} else if (page.equals("Sign In")) {
			Assert.assertEquals(true, loginPage.isSignInTextDisplayed());
			util.sleep(SleepTime.TWO_SEC);
		} else if (page.equals("Pending Approval")) {
			Assert.assertEquals(true, pendingApprovalPage.isPendingAppMenuDisplayed());
			util.sleep(SleepTime.TWO_SEC);
		} else if (page.equals("Pending Assignment")) {
			Assert.assertEquals(true, pendingAssignPage.isPendingAssignMenuDisplayed());
			util.sleep(SleepTime.TWO_SEC);
		}
	}
	
	@When("^I click on the \"([^\"]*)\" icon$") 
	public void plusIcons(String plus) throws Throwable {
		if (plus.equals("pending Approval plus")) {
			pendingApprovalPage.clickPlusIcon();
		} else if (plus.equals("Pending Assignment plus")) {
			pendingAssignPage.clickPlusIcon();
		}
	}

	
	@Then("^I should click on the \"([^\"]*)\" Button$")
	public void requestButton(String button) throws Throwable {
		if (button.equals("Approval Ok")) {
			Assert.assertEquals(true, pendingApprovalPage.isApproveButtonDisplayed());	
		} else if (button.equals("Assign Ok")) {
			Assert.assertEquals(true, pendingAssignPage.isAssignButtonDisplayed());
		}
	}

	@When("^I click on Logout option in Book Transport Page$")
	public void clickLogout() throws Throwable {
		headerPanel.clickLogout();
		util.sleep(SleepTime.THREE_SEC);
	}
	
	@Then("^I should see \"([^\"]*)\" option in Book Transport Page$")
	public void logoutOptionPresent(String logout) throws Throwable {
		Assert.assertEquals(true, headerPanel.isLogoutDisplayed());
		util.sleep(SleepTime.ONE_SEC);
	}
}