package se.test.scripts.cucumber.stepdefinitions;

import cucumber.api.java.en.Then;
import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.PendingApprovalPage;

public class PendingApproval_SD extends BaseClass {
	
	PendingApprovalPage pendingApprovalPage = new PendingApprovalPage(driver);
	Utilities util = new Utilities();

	 
	@Then("^I should click on the Approve Request$")
    public void clickApproveButton() throws Throwable {
	 	pendingApprovalPage.clickApprovetButton();
        util.sleep(SleepTime.TWO_SEC);
 	}	
}
