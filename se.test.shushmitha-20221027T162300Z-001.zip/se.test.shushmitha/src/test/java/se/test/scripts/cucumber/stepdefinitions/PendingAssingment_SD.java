package se.test.scripts.cucumber.stepdefinitions;

import cucumber.api.java.en.Then;
import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.PendingAssignmentPage;

public class PendingAssingment_SD extends BaseClass{
	
	PendingAssignmentPage pendingAssignPage = new PendingAssignmentPage(driver);
	Utilities util = new Utilities();
		
	@Then("^I should select cab operator$")
    public void selectCabOperator() throws Exception{
		pendingAssignPage.selectCabOperator();
        util.sleep(SleepTime.TWO_SEC);
    }
	
	@Then("^I should click on Assign Request$")
    public void clickAssignButton() throws Exception{
	 	pendingAssignPage.clickAssignButton();
        util.sleep(SleepTime.TWO_SEC);
    }
}
