package se.test.scripts.pom;

import org.testng.Assert;
import org.testng.annotations.Test;

import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.HeaderPanel;
import se.test.pages.LoginPage;

public class Scenario1 extends BaseClass {

	LoginPage loginPage;
	HeaderPanel headerPanel;

	Utilities util = new Utilities();

	@Test
	public void validLoginTest() throws Exception {
		loginPage = new LoginPage(driver);
		headerPanel = new HeaderPanel(driver);
		
		boolean textVerify = loginPage.isSignInTextDisplayed();
		Assert.assertEquals(true, textVerify);
		
		loginPage.setValidUserName("EMP");
		util.sleep(SleepTime.ONE_SEC);

		loginPage.setPassWord("EMP");
		util.sleep(SleepTime.ONE_SEC);

		loginPage.clickLoginButton();	
	
		util.sleep(SleepTime.ONE_SEC);
		Assert.assertEquals(true, headerPanel.isLogoutDisplayed());		
        
		headerPanel.clickLogout();		
		util.sleep(SleepTime.ONE_SEC);

		boolean logoutVerify = loginPage.isSignInTextDisplayed();
		Assert.assertEquals(true, logoutVerify);				
		util.sleep(SleepTime.THREE_SEC);
	}
	
	@Test
	public void invalidLoginTest() throws Exception {
		
		loginPage = new LoginPage(driver);
		
		loginPage.setInValidUserName();
		util.sleep(SleepTime.ONE_SEC);
		loginPage.setInvalidPassWord();
		util.sleep(SleepTime.ONE_SEC);
		
		loginPage.clickLoginButton();
		util.sleep(SleepTime.ONE_SEC);
		boolean loginVerify = loginPage.isSignInTextDisplayed();
		Assert.assertEquals(true, loginVerify);

		util.sleep(SleepTime.THREE_SEC);
	}
}