package se.test.scripts.pom;

import org.testng.Assert;
import org.testng.annotations.Test;

import se.test.common.BaseClass;
import se.test.helpers.Utilities;
import se.test.helpers.Utilities.SleepTime;
import se.test.pages.BookTransportPage;
import se.test.pages.HeaderPanel;
import se.test.pages.LoginPage;

public class Scenario2 extends BaseClass {
	LoginPage loginPage;
	BookTransportPage bookTransport;
	HeaderPanel headerPanel;

	Utilities util = new Utilities();
	
	String bookingID = null;
	
	@Test
	public void bookTransport() throws Exception {
		loginPage = new LoginPage(driver);	
		bookTransport = new BookTransportPage(driver);
		headerPanel = new HeaderPanel(driver);
		
		loginPage.setValidUserName("EMP");
		util.sleep(SleepTime.ONE_SEC);

		loginPage.setPassWord("EMP");
		util.sleep(SleepTime.ONE_SEC);
		
		loginPage.clickLoginButton();
		Assert.assertEquals(true, headerPanel.isLogoutDisplayed());				
		util.sleep(SleepTime.ONE_SEC);
		
		bookTransport.selectJourneyDate();
		util.sleep(SleepTime.ONE_SEC);
		bookTransport.selectJourneyTime();
		util.sleep(SleepTime.ONE_SEC);
		bookTransport.fillStartpoint("startPoint");
		util.sleep(SleepTime.ONE_SEC);
		bookTransport.fillDropPoint("dropPoint");
		util.sleep(SleepTime.ONE_SEC);
		bookTransport.fillPurpose("purpose");
		util.sleep(SleepTime.ONE_SEC);
		
		bookTransport.submitCreateRequest();		
		util.sleep(SleepTime.TWO_SEC);
		
	/*	bookingID = bookTransport.getBookingId();
		Assert.assertNotNull(bookingID);
		util.sleep(SleepTime.TWO_SEC);*/
		
		bookTransport.clickOkButton();
		util.sleep(SleepTime.ONE_SEC);
		
		headerPanel.clickLogout();
		boolean logoutVerify = loginPage.isSignInTextDisplayed();
		Assert.assertEquals(true, logoutVerify);						
		util.sleep(SleepTime.THREE_SEC);
	}		
}
